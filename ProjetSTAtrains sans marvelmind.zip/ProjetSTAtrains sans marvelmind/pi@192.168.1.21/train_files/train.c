#include "Libs_Unirail/CAN/canLinux.h"
#include "Libs_Unirail/CAN/MESCAN1_VarTrain.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <semaphore.h>
#include <time.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include "Libs_Unirail/CAN/canLinux.h"
#include "Libs_Unirail/CAN/loco_Parametres.h"


//test
#define DISTANCE_SECURITE 100 //en cm
#define DISTANCE_ARRET_URGENCE 50 //en cm

/**
 * @brief  Recu depuis le train vers le serveur
 * @note   
 *
*/
struct CommunicationVersServeur{
    float distance_parcourue;
    float vitesse;
    int code_erreur;
};

/**
 * @brief  Recu depuis le serveur vers le train
 * @note   
 *
*/
struct CommunicationRecueServeur{
    float distance_a_parcourir;
    float vitesse_consigne;
    int code_erreur;
};

bool update_server = false;
pthread_mutex_t update_server_mutex;


#define DISTANCE_PARCOURS 50
///longueurs des cantons 1 a 9 (grande boucle), en cm.
const int sectionsLength[] = {167, 190, 226, 162, 161, 213, 184, 163, 279};

typedef struct TrainInfo
{
	float distance;  // en cm
	float vit_consigne;
	float vit_mesuree;
	int nb_impulsions;
}TrainInfo;

unsigned char varDebug1, varDebug2;

//////////////////////////////////////////
/// Ecriture de la Trame vitesse limite
///////////////////////////////////////////
int WriteVitesseLimite(float vitesseLimite)
{

	uCAN1_MSG consigneUrgence;
	
	if(vitesseLimite > MAX_CONSIGNE_VITESSE_AUTORISEE) //vitesse supérieur à 50 cm/s
	vitesseLimite = MAX_CONSIGNE_VITESSE_AUTORISEE;                   
	
	consigneUrgence.frame.id  = MC_ID_CONSIGNE_VITESSE_LIMITE;
	consigneUrgence.frame.dlc = MC_DLC_CONSIGNE_VITESSE_LIMITE;
	MESCAN_SetData8(&consigneUrgence, cdmc_consigneVitesseLimite, vitesseLimite);
	
	canLinux_transmit(CANLINUX_PRIORITY_HIGH, &consigneUrgence);
	return 1;
}

//////////////////////////////////////////
/// Ecriture de la Trame Consigne
///////////////////////////////////////////
int WriteVitesseConsigne(unsigned int vitesse, unsigned char sens)
{
	
	uCAN1_MSG consigneVitesse;

	if(vitesse>MAX_CONSIGNE_VITESSE_AUTORISEE) //vitesse supérieur à 50 cm/s
		vitesse = MAX_CONSIGNE_VITESSE_AUTORISEE;
	
	consigneVitesse.frame.id  = MC_ID_CONSIGNE_VITESSE;
	consigneVitesse.frame.dlc = MC_DLC_CONSIGNE_VITESSE;
	MESCAN_SetData8(&consigneVitesse, cdmc_consigneVitesse, vitesse);
	MESCAN_SetBit(&consigneVitesse, bdmc_consigneSensDeplacement, sens);
	
	canLinux_transmit(CANLINUX_PRIORITY_HIGH, &consigneVitesse);
	return 1;
}


//////////////////////////////////////////
/// Envoi de la trame status de RPI1
///////////////////////////////////////////
int  WriteTrameStatusRUNRP1(unsigned char status, unsigned char varDebug1, unsigned char varDebug2)
{
	uCAN1_MSG trameStatusRP1;
	trameStatusRP1.frame.id  = MC_ID_RP1_STATUS_RUN;
	trameStatusRP1.frame.dlc = MC_DLC_RP1_STATUS_RUN;
	MESCAN_SetData8(&trameStatusRP1, cdmc_RP1_erreurs, 0);
	MESCAN_SetData8(&trameStatusRP1, cdmc_RP1_warnings, 0);
	MESCAN_SetBit(&trameStatusRP1, bdmc_RP1_etatConnexionWIFI, 1);
	MESCAN_SetData8(&trameStatusRP1, cdmc_RP1_configONBOARD, status);
	MESCAN_SetData8(&trameStatusRP1, cdmc_RP1_var1Debug, varDebug1);
	MESCAN_SetData8(&trameStatusRP1, cdmc_RP1_var2Debug, varDebug2);
	
	canLinux_transmit(CANLINUX_PRIORITY_HIGH, &trameStatusRP1);
	return 1;	
}

//////////////////////////////////////////
/// Identification de la trame CAN
///////////////////////////////////////////
void TraitementDonnee (uCAN1_MSG *recCanMsg, TrainInfo *infos)
{
	unsigned char status = 0;
	
    switch (recCanMsg->frame.id)
    {
		/** Recuperer Info BALISE  **/
		case MC_ID_EBTL2_RECEIVED :
        //MAJ_Info_BALISE (XXX);
			printf("Balise %i.\n", MESCAN_GetData8(recCanMsg, cdmc_sourceNumeroBalise));
        break ;
		case MC_ID_MESSAGE_GSM_RECEIVED:
        //MAJ_GSMR(XXX);
        break;
		case MC_ID_SCHEDULEUR_MESURES  : /** Envoi la vitesse instantannée (consigne vitesse) ,	le nombre d’impulsions, la vitesse mesurée, l’erreur du PID **/
			if(MESCAN_GetData8(recCanMsg, cdmc_ordonnancementId)==MC_ID_RP1_STATUS_RUN)
				//WriteTrameStatusRUNRP1(status, varDebug1, varDebug2);
			infos-> vit_mesuree= (int)MESCAN_GetData8(recCanMsg, cdmc_vitesseMesuree);/** le nbre d'implusion envoyé ici
			// est le nombre d'impulsion entre 2 mesures **/
			infos-> nb_impulsions+= infos-> vit_mesuree;
			infos-> distance= PAS_ROUE_CODEUSE * (infos->nb_impulsions);
			infos-> vit_consigne= (float)MESCAN_GetData8(recCanMsg, cdmc_vitesseConsigneInterne);
		break;
		
		default :
			printf("frame est de can id %X \n",recCanMsg->frame.id);
		break;
	}
}

////////////////////////////////////////
/// MAIN
////////////////////////////////////////


struct CommunicationVersServeur comServ = {0};
struct CommunicationRecueServeur comrecuServ = {0};
/**
 * @brief  Détermine si oui ou non la variable position a été actualisée
 * @note   variable globale
 *
*/
bool ecriture_update = false;
//détermine quand il faut terminer le programme
bool terminateProgram=false;
/**
 * @brief  Détermine si oui ou non les consigne envoyer par le serveur ont été actualisée
 * @note   variable globale
 *
*/
bool consigne_update = false;

//port du serveur (connexion TCP)
int port = 0;
char adresse[20] = "127.0.0.1";
/**
 * @brief  Permet d'empêcher la lecture et l'écriture simultanée dans la variable position
 * @note   variable globale
 *
*/
pthread_mutex_t mutex_lock_communication_vers_serveur;
pthread_mutex_t mutex_lock_communication_depuis_serveur;
/**
 * @brief  Fonction définie dans la doc du marvel mind qui arrête le programme
 * @note   
 * @param  signum: 
 * @retval None
 *
*/
void CtrlHandler(int signum){
    terminateProgram=true;
}


//variable définie dans l'exemple de marvel mind
struct timespec ts;





void * reception_message(void * p_client_socket){
  int client_socket = *((int *) p_client_socket);
  while(1){
    int bytes_received = read(client_socket, &comrecuServ, sizeof(comrecuServ));
    if(bytes_received == -1){
      perror("Erreur lors de l'envoie des donnée");
      exit(EXIT_FAILURE);
    }
    
  }
  return NULL;
}



/**
 * @brief  envoie un message si la position a été mise à jour
 * @note   
 * @param  client_socket: socket du client
 * @retval true si la position a été actualisée, false sinon
 *
*/
void handler_envoie_message(int client_socket){
    //blocage du mutex
    pthread_mutex_lock(&mutex_lock_communication_vers_serveur);
    if(ecriture_update){//si la position a été actualisée

        
        //envoie des données
        write(client_socket,&comServ,sizeof(comServ));

        
        //spécification que l'info a été envoyée
        ecriture_update = false;
        //déblocage du mutex
        pthread_mutex_unlock(&mutex_lock_communication_vers_serveur);

        return;
    }
    //déblocage du mutex
    pthread_mutex_unlock(&mutex_lock_communication_vers_serveur);
    return;
}


/**
 * @brief  Communique avec le serveur
 * @note   A chaque actualisation de la position, envoie la position au serveur
 * @param  arg: NULL
 * @retval NULL
 *
*/
void * communiquer(void * arg){
    //Création socket connexion

    //variable socket qui gère la connexion avec le serveur
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("Erreur lors de la création du socket client\n");
        exit(EXIT_FAILURE);
    }

    //adresse du serveur
    struct sockaddr_in addr_serv;
    addr_serv.sin_family = AF_INET;
    addr_serv.sin_port = htons(port);
    addr_serv.sin_addr.s_addr = inet_addr(adresse); //adresse locale

    printf("Tentative de connexion...\n");
    //tentative de connexion au serveur
    if (connect(client_socket, (struct sockaddr*)&addr_serv, sizeof(addr_serv)) == -1) {
        //si la tentative a échouée
        perror("Erreur lors de la connexion au serveur\n");
        close(client_socket);
        exit(EXIT_FAILURE);
    }
    printf("Succès de la connexion !\n");
    pthread_t threadReception; 
    int socket_thread_communication = client_socket;
    pthread_create(&threadReception,NULL,reception_message,(void *) &client_socket);
    
    while(1){
        //Pour une raison étrange, je n'arrive pas à utiliser les signaux
        //pour cette fonction... J'utilise donc usleep
        handler_envoie_message(client_socket);
        usleep(1000 * 300);
    }

    return NULL;
    
}


void handler_pause(){
}


int main (int argc, char *argv[]){
  // get port name from command line arguments (if specified)
  //lecture de l'argument du port
  if(argc >= 2)port = atoi(argv[1]);
  else{
      printf("Aucun port spécifié (2e position en argument !\n)");
  }
  //lecture de l'adresse:
  if(argc >= 3)
  strcpy(adresse,argv[2]);
  // Initialisation


  

  uCAN1_MSG recCanMsg;
	int fd;
	struct TrainInfo train1;
	int canPort;
	char *NomPort = "can0";
	struct can_filter rfilter[2]; 
	rfilter[0].can_id   = 0x02F;
	rfilter[0].can_mask = CAN_SFF_MASK;

	train1.distance =0;
	train1.vit_consigne =0;
	train1.vit_mesuree =0;
	train1.nb_impulsions =0;

  /* Creation du descripteur de port a utilise pour communiquer sur le bus CAN */
  canPort = canLinux_init_prio(NomPort);
  // Mise en place d'un filtre
  canLinux_initFilter(rfilter, sizeof(rfilter));
  
  // Deverouillage de la limite de vitesse autorisee
  WriteVitesseLimite(MAX_CONSIGNE_VITESSE_AUTORISEE);


  //Lancement de la communication

  //Variable thread qui gère la communication
  pthread_mutex_init(&mutex_lock_communication_vers_serveur,NULL);
  pthread_t thread_communication;
  pthread_create(&thread_communication,NULL,communiquer,NULL);


  pthread_mutex_init(&update_server_mutex,NULL);
  float distance_temp;
  float EOA;
  // Main loop
  while (1){
    
	 ts.tv_sec += 2;
        
    //Traitement de la trame pour evaluer la distance de deplacement du train
    TraitementDonnee(&recCanMsg, &train1); 
    
    
    //Ecriture d'une nouvelle consigne de vitesse
    pthread_mutex_lock(&mutex_lock_communication_vers_serveur);
    comServ.vitesse = train1.vit_mesuree;
    comServ.distance_parcourue = train1.distance;
    pthread_mutex_unlock(&mutex_lock_communication_vers_serveur);
    
    
    
    
    pthread_mutex_lock(&mutex_lock_communication_depuis_serveur);
    pthread_mutex_lock(&update_server_mutex);

    if(update_server){
      distance_temp = train1.distance;
      EOA = comrecuServ.distance_a_parcourir;
      update_server = false;
    }
    pthread_mutex_unlock(&update_server_mutex);

    if(comrecuServ.code_erreur>0){
      WriteVitesseConsigne(0, 1);
      printf(" ========== ARRET URGENCE ========== \n");
    }else{
      if(EOA+distance_temp - DISTANCE_SECURITE >train1.distance)
      {
        printf("Entrée dans EOA, décélération\n");
        WriteVitesseConsigne(comrecuServ.vitesse_consigne/2,1);
      }
      else if (EOA+distance_temp-DISTANCE_ARRET_URGENCE>train1.distance)
      {
        printf("Entrée distance sécurité critique, arrêt immédiat !\n");
        WriteVitesseConsigne(0,1);
      }
      else
      {
        WriteVitesseConsigne(comrecuServ.vitesse_consigne, 1);
      }
      
    }

    pthread_mutex_unlock(&mutex_lock_communication_depuis_serveur);

    //Attente de 100ms
    usleep(100 * 1000);
  }
    

  return 0;
}

